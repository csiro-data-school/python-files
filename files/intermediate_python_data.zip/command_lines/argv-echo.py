import sys
for index, arg in enumerate(sys.argv):
    print("{0}: {1}".format(index, arg))
